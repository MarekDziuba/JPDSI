package com.jsfcourse.calc;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.enterprise.context.RequestScoped;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;

@Named
@RequestScoped
//@SessionScoped
public class KredytBB {
	private int lo;
	private int yr;
	private double pe;
	private String loan;
	private String years;
	private String perc;
	private Double result;

	@Inject
	FacesContext ctx;


	public String getLoan() {
		return loan;
	}

	public void setLoan(String loan) {
		this.loan = loan;
	}

	public String getYears() {
		return years;
	}

	public void setYears(String years) {
		this.years = years;
	}

	public String getPerc() {
		return perc;
	}

	public void setPerc(String perc) {
		this.perc = perc;
	}

	public Double getResult() {
		return result;
	}
	
	public void setResult(Double result) {
		this.result = result;
	}

	public boolean doTheMath() {
		try {

			lo = Integer.valueOf(this.loan);
			yr = Integer.valueOf(this.years);
			pe = Double.parseDouble(this.perc);
			
			if(!range()) {
				return false;
			}	
			
			double months = yr * 12;
			double ods = lo * yr * (pe/100);
			double all = lo + ods;
			result = all/months;
			
			result = Math.round(result * 100.0) / 100.0;
			
			ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Operacja wykonana poprawnie", null));
			return true;
			
		} catch (Exception e) {
			isEmpty();				
			return false;
		}
	}

	// Go to "showresult" if ok
		public String calc() {
			if (doTheMath()) {
				return "showresult";
			}
			return null;
		}

		// Put result in messages on AJAX call
		public String calc_AJAX() {
			if (doTheMath()) {
				ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Miesięczna rata to: " + result + "zł", null));
			}
			return null;
		}

		public String info() {
			return "info";
		}
		
		public boolean range() {
			if (lo < 10000 || lo > 30000) {
				ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Przedział kredytu się nie zgadza", null));
				return false;
			}
			if (yr < 5 || yr > 20) {
				ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Przedział lat się nie zgadza", null));
				return false;
			}
			if (pe < 5 || pe > 20) {
				ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Przedział oprocentowania się nie zgadza", null));
				return false;
			}
			return true;
		}
		
		public boolean isEmpty() {
			if (loan.isEmpty()) {
				ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Pole kredyt jest puste", null));
				return false;
			}
			if (years.isEmpty()) {
				ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Pole lat jest puste", null));
				return false;
			}
			if (perc.isEmpty()) {
				ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Pole oprocentowanie jest puste", null));
				return false;
			}
			return false;
		}
		
	}